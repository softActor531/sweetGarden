<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/clients-boxes/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/clients-boxes/clients-boxes.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/clients-boxes/clients-boxes-item.php';
