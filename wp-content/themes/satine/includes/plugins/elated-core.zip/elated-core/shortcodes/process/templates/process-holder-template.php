<div <?php satine_elated_class_attribute($holder_classes); ?>>
	<div class="eltdf-process-bg-holder"></div>
	<div class="eltdf-process-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>