<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/pricing-item/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/pricing-item/pricing-item.php';