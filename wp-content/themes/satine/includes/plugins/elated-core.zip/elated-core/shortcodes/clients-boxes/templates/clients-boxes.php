<div class="eltdf-clients-boxes-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="eltdf-cb-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>