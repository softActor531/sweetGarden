<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/overlapping-text/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/overlapping-text/overlapping-text.php';