<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/quote-section/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/quote-section/quote-section.php';