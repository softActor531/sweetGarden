<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/parallax/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/parallax/parallax.php';

