<<?php echo esc_attr($title_tag); ?> class="eltdf-custom-font-holder <?php echo esc_attr($holder_classes); ?>" <?php satine_elated_inline_style($holder_styles); ?> <?php echo satine_elated_get_inline_attrs($holder_data); ?>>
	<?php echo esc_html($title); ?>
</<?php echo esc_attr($title_tag); ?>>