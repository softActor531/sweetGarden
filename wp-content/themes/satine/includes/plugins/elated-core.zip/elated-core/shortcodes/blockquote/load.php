<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/blockquote/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/blockquote/blockquote.php';