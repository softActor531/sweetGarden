<div class="eltdf-ps-info-item eltdf-ps-content-item">
    <h2 class="eltdf-portfolio-item-title"><?php the_title(); ?></h2>
    <?php the_content(); ?>
</div>