<?php

get_header();

satine_elated_get_title(false, 'portfolio_single');

eltdf_core_get_single_portfolio();

get_footer();