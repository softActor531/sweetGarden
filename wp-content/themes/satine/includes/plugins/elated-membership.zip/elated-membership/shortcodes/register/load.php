<?php

include_once ELATED_MEMBERSHIP_SHORTCODES_PATH.'/register/functions.php';
include_once ELATED_MEMBERSHIP_SHORTCODES_PATH.'/register/register.php';