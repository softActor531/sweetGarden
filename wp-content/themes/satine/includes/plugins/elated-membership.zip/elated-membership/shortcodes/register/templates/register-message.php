<div class="eltdf-register-notice">
	<h5><?php echo esc_html($message); ?></h5>
	<a href="#" class="eltdf-login-action-btn" data-el="#eltdf-login-content" data-title="<?php esc_html_e('LOGIN', 'eltdf_membership'); ?>"><?php esc_html_e('LOGIN', 'eltdf_membership'); ?></a>
</div>