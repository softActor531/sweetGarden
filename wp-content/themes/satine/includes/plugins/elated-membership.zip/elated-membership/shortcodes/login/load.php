<?php
include_once ELATED_MEMBERSHIP_SHORTCODES_PATH.'/login/functions.php';
include_once ELATED_MEMBERSHIP_SHORTCODES_PATH.'/login/login.php';